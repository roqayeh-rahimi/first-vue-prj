<template>
  <h1>404</h1>
  <h3>Not Found Page</h3>
</template>

<script>
export default {

}
</script>

<style>

</style>
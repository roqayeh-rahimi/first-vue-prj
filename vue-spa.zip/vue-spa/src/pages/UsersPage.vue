<template>
  <h1>{{ title }}</h1>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Iste fuga illum cupiditate ipsum? Possimus quis dicta non earum, distinctio libero recusandae culpa nemo in? Neque provident suscipit culpa molestias, possimus nam unde asperiores voluptatum nihil aspernatur repudiandae, corporis ex illo porro iusto nobis accusantium sed. Modi autem quisquam explicabo architecto obcaecati. Alias quibusdam dolores provident magnam harum tempora, commodi fugiat nihil obcaecati dolore maxime voluptate exercitationem delectus tenetur. Nemo facilis assumenda blanditiis? Modi dolorum repellendus, molestias dolores reiciendis distinctio explicabo dignissimos cum nesciunt, eius eveniet voluptates. Distinctio amet a aliquid voluptas. Nesciunt inventore quod quos. Modi, ipsa ut? Ipsam, id!</p>
</template>

<script>
export default {
    setup(){
        let title = "Users Page"
        return{title}
    }
}
</script>

<style>

</style>
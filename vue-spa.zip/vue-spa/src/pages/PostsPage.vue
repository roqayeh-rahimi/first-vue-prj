<template>
  <h1>{{ title }}</h1>
  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis autem, dignissimos ex fugit nesciunt accusantium ipsum rem dolorem maxime saepe, vitae nihil id iste suscipit. Quas tempore reprehenderit praesentium magni numquam animi error tenetur unde asperiores libero excepturi fuga repellendus in optio quae quod aperiam nisi aliquam nulla doloribus voluptatum atque, quam repellat hic. Fuga maxime eos eligendi, praesentium quisquam harum debitis. Tempora consequatur porro vitae soluta possimus explicabo quam minima similique, praesentium quod fuga, architecto, enim in hic iste dolorem magnam dolores adipisci voluptas sed. Repudiandae quia mollitia assumenda facere ratione autem dolor quibusdam possimus, iusto, architecto neque maiores?</p>
</template>

<script>
export default {
setup(){
    let title = 'Post Page'
    return{title}
}
}
</script>

<style>

</style>